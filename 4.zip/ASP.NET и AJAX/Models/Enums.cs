namespace TaskFlow.Models;

// Роли пользователей — основа авторизации
public enum UserRole
{
    User = 0,      // исполнитель: видит свои задачи, меняет статус, комментирует
    Manager = 1,   // менеджер: создаёт проекты и задачи, видит всё
    Admin = 2      // админ: всё + управление пользователями и статистика
}

public enum TaskItemStatus
{
    New = 0,
    InProgress = 1,
    Done = 2,
    Cancelled = 3
}

public enum TaskPriority
{
    Low = 0,
    Medium = 1,
    High = 2,
    Critical = 3
}